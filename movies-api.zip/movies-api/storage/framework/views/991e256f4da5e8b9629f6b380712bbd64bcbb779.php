<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>PDF</title>
    <style>
        body,html {
            padding: 0;
            margin: 0;
        }
        * {
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<table class="table">
    <thead>
    <tr>
        <th>Movie Title</th>
        <th>Movie Description</th>
        <th>Movie Start Date</th>
        <th>Movie End Date</th>
        <th>Chair Price</th>
        <th>Chair Row</th>
        <th>Chair Column</th>
        <th>User Name</th>
        <th>User Email</th>
        <th>Chair Reserved At</th>
    </tr>
    </thead>
    <tbody class=" text-center">
    <?php $__currentLoopData = $movie->chairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center">
            <td><?php echo e($movie->title); ?></td>
            <td><?php echo e($movie->description); ?></td>
            <td><?php echo e($movie->start_date); ?></td>
            <td><?php echo e($movie->end_date); ?> </td>
            <td><?php echo e($chair->price); ?></td>
            <td><?php echo e($chair->row); ?></td>
            <td><?php echo e($chair->column); ?></td>
            <td><?php echo e($chair->user?->name ?? 'Not Reserved'); ?></td>
            <td><?php echo e($chair->user?->email ?? 'Not Reserved'); ?></td>
            <td><?php echo e($chair->reserved_at ?? 'Not Reserved'); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</body>
</html>
<?php /**PATH C:\Users\HoldMyCup\Desktop\uktra\movies-api\resources\views/pdf.blade.php ENDPATH**/ ?>